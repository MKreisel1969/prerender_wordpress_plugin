<?php
/**
 * Plugin Name: Prerender.io Integration in Wordpress
 * Plugin URI: 
 * Description: Integrates Prerender.io service for dynamic rendering of JavaScript-based pages with admin token configuration. See settings...
 * Version: 1.1
 * Author: Matthias Kreisel & ChatGPT 2024-09-27
 * Author URI: 
 */

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

class Prerender_Integration {

    // Constructor
    public function __construct() {
        // Add settings field in admin panel
        add_action('admin_menu', array($this, 'add_plugin_settings_page'));
        add_action('admin_init', array($this, 'prerender_settings_init'));

        // Add hook to apply Prerender.io token on frontend
        add_action('template_redirect', array($this, 'prerender_io_integration'));
    }

    // Add a settings page in WordPress Admin
    public function add_plugin_settings_page() {
        add_options_page(
            'Prerender.io Settings', // Page title
            'Prerender.io Settings', // Menu title
            'manage_options',        // Capability
            'prerender-integration', // Menu slug
            array($this, 'settings_page_html') // Callback to display the page
        );
    }

    // Initialize settings
    public function prerender_settings_init() {
        register_setting('prerenderSettings', 'prerender_token'); // Register the setting

        // Add settings section and field
        add_settings_section(
            'prerender_section', // Section ID
            'Prerender.io Settings', // Section Title
            null, // Callback (not needed)
            'prerender-integration' // Page slug
        );

        add_settings_field(
            'prerender_token_field', // Field ID
            'Prerender.io Token', // Field Title
            array($this, 'prerender_token_field_html'), // Callback to display the field
            'prerender-integration', // Page slug
            'prerender_section' // Section ID
        );
    }

    // HTML for the token input field
    public function prerender_token_field_html() {
        $token = get_option('prerender_token');
        echo '<input type="text" id="prerender_token" name="prerender_token" value="' . esc_attr($token) . '" />';
    }

    // HTML for the settings page
    public function settings_page_html() {
        ?>
        <div class="wrap">
            <h1>Prerender.io Integration Settings</h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('prerenderSettings');
                do_settings_sections('prerender-integration');
                submit_button('Save Settings');
                ?>
            </form>
        </div>
        <?php
    }

    // Function to check User-Agent and apply Prerender.io
    public function prerender_io_integration() {
        // Get the token from the database
        $prerenderToken = get_option('prerender_token');

        if (!$prerenderToken) {
            return; // Exit if no token is set
        }

        // Prerender.io User-Agent-List
        $crawlerUserAgents = [
            'googlebot', 'bingbot', 'yandex', 'baiduspider',
            'facebookexternalhit', 'twitterbot', 'rogerbot', 'linkedinbot',
            'embedly', 'quora link preview', 'showyoubot', 'outbrain', 'pinterest'
        ];

        // Get the current User Agent
        $userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);

        // Check if User Agent is a bot
        foreach ($crawlerUserAgents as $crawlerAgent) {
            if (strpos($userAgent, $crawlerAgent) !== false) {
                // Send the Prerender.io header
                header('X-Prerender-Token: ' . $prerenderToken);

                // Set the URL for the Prerender.io service
                $prerenderURL = 'https://service.prerender.io/' . $_SERVER['REQUEST_URI'];
                header('Location: ' . $prerenderURL);
                exit();
            }
        }
    }
}

// Initialize the plugin
new Prerender_Integration();